# Wifi firmware to get wifi running on Linux on MacBook Pro 16,1 (16 inch, 2019).

The firmware has been extracted from **macOS Montery**.

For more details refer to this [t2linux wiki](https://wiki.t2linux.org/guides/wifi/).
